import {View, Text} from 'react-native';
export default function App(){
  return(
    <View>
      <Text>Hello, World</Text>
    </View>
  )
};
